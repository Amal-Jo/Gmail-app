package com.parse.mygmailapp;

public class Config {
    public static final String EMAIL ="thisisfortry38@gmail.com";
    public static final String PASSWORD ="Qwerty@123";

}
