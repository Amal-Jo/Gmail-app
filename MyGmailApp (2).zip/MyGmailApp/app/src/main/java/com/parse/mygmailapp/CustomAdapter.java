package com.parse.mygmailapp;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CustomAdapter extends ArrayAdapter {
    //to reference the Activity
    private final Activity context;

    //to store the emails
    private final List<Mail> emailArray;

    private boolean checkboxVisible = false;

    private List<String> selectedStrings = new ArrayList<String>();

    public CustomAdapter(Activity context, List<Mail> emailArray) {
        super(context,R.layout.list, emailArray);
        this.context = context;
        this.emailArray = emailArray;

    }
    public View getView(final int position, View view, ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.list, null,true);
        boolean cheked;
        //this code gets references to objects in the listview_row.xml file
        TextView  ReEmail =(TextView)rowView.findViewById(R.id.rEmail);
        TextView ReSubject=(TextView)rowView.findViewById(R.id.rsubject);
        TextView ReMessage=(TextView)rowView.findViewById(R.id.rmessage);
        CheckBox checkBox = (CheckBox)rowView.findViewById(R.id.rcheckbox);

        //this code sets the values of the objects to values from the arrays
        ReEmail.setText(emailArray.get(position).getArEmail());
        ReSubject.setText(emailArray.get(position).getArSubject());
        ReMessage.setText(emailArray.get(position).getArMessage());
        if(checkboxVisible) {
            checkBox.setVisibility(View.VISIBLE);

            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                    if (isChecked) {
                        Log.d("check", String.valueOf(position));
                        selectedStrings.add(Integer.toString(position));

                    } else {
                        Log.d("check", String.valueOf(position));
                        selectedStrings.remove(Integer.toString(position));
                    }
                }
            });

        }
        else {
            checkBox.setVisibility(View.INVISIBLE);
        }

        return rowView;

    };

    @Override
    public int getCount() {
        return emailArray.size();
    }

    public void setEmail(List<Mail> email){

        emailArray.addAll(email);

    }

    public void setCheckboxVisible(boolean b){
        checkboxVisible = b;
    }

    public List<String> getSelectedStrings() {
        return selectedStrings;
    }
}
