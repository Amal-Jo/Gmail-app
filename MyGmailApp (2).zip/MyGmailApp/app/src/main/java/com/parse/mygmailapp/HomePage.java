package com.parse.mygmailapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class HomePage extends AppCompatActivity  {
    String names[];
    String Email;
    String ss[]=new String[10];
    String Subject;
    String Message;
    Button compose,delete;
    ListView listView;
   List<String> EmailArray = new ArrayList<>();

    String []SubjectArray={"aa","aa","aa"};
    String []MessageArray={"ss","ss","ss"};
    List<Mail> emailList = new ArrayList<>();
    ReceiveMail receiveMail;
    String[] listItem;
    CustomAdapter adapter;
    boolean checkbox = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        Log.i("test","homepage onCreate");
        setTitle("Home");
        EmailArray.add("hhj");
        EmailArray.add("sefr");
        EmailArray.add("ets");

        adapter = new CustomAdapter(this,emailList);
        listView=(ListView)findViewById(R.id.listView);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        listView.setAdapter(adapter);
        receiveEmail();

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("checkbox","Long click");
                checkbox = !checkbox;
                adapter.setCheckboxVisible(checkbox);
                adapter.notifyDataSetChanged();
                return false;
            }
        });
        compose=(Button)findViewById(R.id.composeButton);
        compose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
            }
        });


    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected( MenuItem item) {

        switch(item.getItemId()) {
            case R.id.action_search:

                return(true);
            case R.id.action_delete:
                return(true);

        }
        return(super.onOptionsItemSelected(item));
    }


    private void receiveEmail() {
        receiveMail = new ReceiveMail(this,Email, Subject, Message);
        try {
            emailList = receiveMail.execute().get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Log.d("yaas","asdsa");
        adapter.setEmail(emailList);
        adapter.notifyDataSetChanged();
        receiveMail.cancel(true);
        Log.d("as","asdsa");


    }

}
