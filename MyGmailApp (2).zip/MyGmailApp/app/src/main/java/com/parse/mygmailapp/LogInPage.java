package com.parse.mygmailapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LogInPage extends AppCompatActivity {


    EditText et_email;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in_page);
        getSupportActionBar().hide();

        et_email=(EditText)findViewById(R.id.email);
        Log.i("testing","outside");

        btn = (Button)findViewById(R.id.submitbtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("test","entered");
                Intent intent = new Intent(getApplicationContext(),HomePage.class);

                String validemail = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +

                        "\\@" +

                        "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +

                        "(" +

                        "\\." +

                        "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +

                        ")+";


                String email = et_email.getText().toString();

                Matcher matcher= Pattern.compile(validemail).matcher(email);


                if (matcher.matches()){
                    Toast.makeText(getApplicationContext(),"True",Toast.LENGTH_LONG).show();
                    startActivity(intent);


                }
                else {
                    Toast.makeText(getApplicationContext(),"Enter Valid Email-Id", Toast.LENGTH_LONG).show();
                }



            }
        });

    }
}
