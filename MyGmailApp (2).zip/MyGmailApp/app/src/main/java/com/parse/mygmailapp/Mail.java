package com.parse.mygmailapp;

public class Mail {

    String arEmail;
    String arSubject;
    String arMessage;

    public String getArEmail() {
        return arEmail;
    }

    public void setArEmail(String arEmail) {
        this.arEmail = arEmail;
    }

    public String getArSubject() {
        return arSubject;
    }

    public void setArSubject(String arSubject) {
        this.arSubject = arSubject;
    }

    public String getArMessage() {
        return arMessage;
    }

    public void setArMessage(String arMessage) {
        this.arMessage = arMessage;
    }

    public Mail(String arEmail, String arSubject, String arMessage) {
        this.arEmail = arEmail;
        this.arSubject = arSubject;
        this.arMessage = arMessage;
    }
}
