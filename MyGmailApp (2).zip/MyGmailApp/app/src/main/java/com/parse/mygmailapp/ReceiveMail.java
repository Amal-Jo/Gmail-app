package com.parse.mygmailapp;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;

public class ReceiveMail extends AsyncTask<Void,Void,List<Mail>> {


    //Declaring Variables
    private Context context;
    private Session session;

    //Information to receive email
    String email;
    String subject;
    String message;

    List<Mail> mails = new ArrayList<>();

    String[] arEmail =new String[100];
    String[] arSubject =new String[100];
    String[] arMessage =new String[100];



    //Class Constructor
    public ReceiveMail(Context context,String email, String subject, String message) {
        //Initializing variables
        this.context = context;
        this.email = email;
        this.subject = subject;
        this.message = message;
    }


    //Set mail properties and configure accordingly
    String hostval = "smtp.gmail.com";
    String mailStrProt = "pop3";
    String uname = Config.EMAIL;
    String pwd = Config.PASSWORD;

    // Calling checkMail method to check received emails
    protected List<Mail> doInBackground(Void... voids) {
        checkMail(hostval, mailStrProt, uname, pwd);
        Log.i("testing","receivemail do in background");
        return mails;
    }


    public void checkMail(String hostval, String mailStrProt, String uname, String pwd)
        {
            Log.i("loop test","entered into checkmail");
            try {
                //Set property values
                Properties props = new Properties();
                props.put("mail.smtp.host", "smtp.gmail.com");
                props.put("mail.smtp.socketFactory.port", "465");
                props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.port", "465");
                Session emailSessionObj = Session.getDefaultInstance(props);
                Log.i("email obj","success");

                //Create POP3 store object and connect with the server
                Store storeObj = emailSessionObj.getStore("pop3s");
                storeObj.connect(hostval, Config.EMAIL,Config.PASSWORD);
                Log.i("email obj","store object");

                //Create folder object and open it in read-only mode
                Folder emailFolderObj = storeObj.getFolder("INBOX");
                emailFolderObj.open(Folder.READ_ONLY);
                Log.i("email obj","folder open");
                //Fetch messages from the folder and print in a loop
                Message[] messageobjs = emailFolderObj.getMessages();

                for (int i = 0, n = messageobjs.length; i < n; i++) {
                    Message indvidualmsg = messageobjs[i];
                    System.out.println("Printing individual messages");
                    System.out.println("No# " + (i + 1));
                    email= String.valueOf(indvidualmsg.getFrom()[0]);
                    subject = indvidualmsg.getSubject();
                    message=indvidualmsg.getContent().toString();

                    mails.add(new Mail(email,subject,message));

                    System.out.println("Email Subject: " + indvidualmsg.getSubject());
                    System.out.println("Sender: " + indvidualmsg.getFrom()[0]);
                    System.out.println("Content: " + indvidualmsg.getContent().toString());
                    System.out.println("array Email:"+ Arrays.asList(arEmail));
                    System.out.println("array Subject:"+ Arrays.asList(arSubject));
                    System.out.println("array Message:"+ Arrays.asList(arMessage));
                }

                //Now close all the objects
                emailFolderObj.close(false);
                storeObj.close();
                Log.i("email obj","folder closed");
            } catch (NoSuchProviderException exp) {
                exp.printStackTrace();
            } catch (MessagingException exp) {
                exp.printStackTrace();
            } catch (Exception exp) {
                exp.printStackTrace();
            }
        }


}
